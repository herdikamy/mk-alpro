 <script type="text/javascript">
                window.location.href="../../halaman_error.php";
            </script>